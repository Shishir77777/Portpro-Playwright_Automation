pRTLPCB(6,[{"t":"c","d":{"t":"n","d":null}}]);
pLPCommand('close',6);
