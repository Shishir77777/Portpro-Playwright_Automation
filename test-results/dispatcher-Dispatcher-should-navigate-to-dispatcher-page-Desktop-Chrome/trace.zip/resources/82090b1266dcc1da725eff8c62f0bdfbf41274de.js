// Upscope configuration for portpro.io

  window.Upscope.__defaultConfiguration = {
  "beta": false,
  "product": "userview",
  "showUpscopeLink": true,
  "showTerminateButton": true,
  "trackConsole": false,
  "allowRemoteConsole": false,
  "allowRemoteScroll": true,
  "allowRemoteClick": true,
  "allowRemoteType": false,
  "allowFullScreen": false,
  "enableSessionRating": false,
  "injectLookupCodeButton": false,
  "enableLookupCodeOnKey": true,
  "requireAuthorizationForSession": true,
  "showAgentRequestButton": "never",
  "collectHistory": false,
  "autoconnect": true,
  "requireControlRequest": false,
  "allowAgentRedirect": true,
  "apiKey": "zAUuxatKfq"
};
  window.Upscope.__defaultRegion = "ap-southeast";

  var scriptUrl = 'https://js.upscope.io/upscope-2025.7.0.js';

  if ('noModule' in HTMLScriptElement.prototype && 'any' in Promise)
    scriptUrl = scriptUrl.replace(/\.js$/, '.es6.js');

  

  (function(){
    var s = document.createElement('script');
    s.type = 'text/javascript';
    s.async = true;
    s.charset = 'utf-8';
    s.src = scriptUrl;
    var x = document.getElementsByTagName('script')[0];
    x.parentNode.insertBefore(s, x);
  })();
