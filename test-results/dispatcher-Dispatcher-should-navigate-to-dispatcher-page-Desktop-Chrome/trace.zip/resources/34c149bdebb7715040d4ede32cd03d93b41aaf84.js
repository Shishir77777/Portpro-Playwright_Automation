
function pLPCommand(c, a1, a2, a3, a4) {
parent.window["pLPCommand3"] && parent.window["pLPCommand3"](c, a1, a2, a3, a4);
}
function pRTLPCB(pN, data) {
parent.window["pRTLPCB3"] && parent.window["pRTLPCB3"](pN, data);
}
         pLPCommand('start','3088798','3xah1xJm80');
pRTLPCB(0,[{"t":"c","d":{"t":"h","d":{"ts":1752334173725,"v":"5","h":"s-usc1a-nss-2032.firebaseio.com","s":"YnpRkzyzDKeL8J9lrSycMhS1PYhjfex5"}}}]);
