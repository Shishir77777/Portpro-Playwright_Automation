pRTLPCB(5,[{"t":"c","d":{"t":"n","d":null}}]);
pLPCommand('close',5);
